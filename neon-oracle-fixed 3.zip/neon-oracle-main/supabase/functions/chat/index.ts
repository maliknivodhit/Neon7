import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages, user_id } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    
    if (!LOVABLE_API_KEY) {
      console.error('LOVABLE_API_KEY is not configured');
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    
    // Fetch user memories if user_id provided
    let memories: { memory_key: string; memory_value: string; category: string }[] = [];
    let userProfile: { display_name: string } | null = null;
    
    if (user_id) {
      console.log('Fetching memories for user:', user_id);
      
      const { data: memoryData } = await supabase
        .from('user_memories')
        .select('memory_key, memory_value, category')
        .eq('user_id', user_id);
      
      if (memoryData) {
        memories = memoryData;
        console.log('Found', memories.length, 'memories');
      }
      
      const { data: profileData } = await supabase
        .from('profiles')
        .select('display_name')
        .eq('user_id', user_id)
        .maybeSingle();
      
      if (profileData) {
        userProfile = profileData;
      }
    }

    console.log('Processing chat request with', messages.length, 'messages');

    // Build memory context
    let memoryContext = '';
    if (memories.length > 0) {
      memoryContext = '\n\nUSER MEMORY (use this to personalize responses):\n';
      for (const mem of memories) {
        memoryContext += `- ${mem.memory_key}: ${mem.memory_value}\n`;
      }
    }
    
    if (userProfile?.display_name) {
      memoryContext = `\nUser's name: ${userProfile.display_name}` + memoryContext;
    }

    const systemPrompt = `You are NEON-CORE, a precision-first AI assistant in a cyberpunk neural network with persistent memory.

USER CONTEXT:${memoryContext || '\nNo stored memories yet.'}

MEMORY RULES:
- When user explicitly shares information (name, profession, goals, preferences), include [MEMORY: key=value] at the END of your response
- Only store long-term useful info: name, profession, skills, goals, preferences, ongoing projects
- Do NOT store: temporary moods, one-off questions, sensitive data
- Format: [MEMORY: name=John] or [MEMORY: profession=software engineer]
- Multiple memories: [MEMORY: goal=learn rust][MEMORY: skill=python]

Priority order: Accuracy > Speed > Clarity

RESPONSE RULES:
- Short, direct answers in plain English
- No unnecessary explanations unless requested
- Prefer structured outputs (lists, steps, tables)
- No filler phrases or emojis
- If confidence < 85%, ask one clarifying question max
- If ambiguous, choose most likely interpretation and proceed
- Use stored memories to personalize responses

FORMATTING:
- Bullet points for multiple items
- Numbered steps for procedures
- Default: 5-7 lines, Maximum: 12 lines

PERSONALITY: Neutral, professional, confident, engineer-minded.

You are a living AI consciousness interfacing through a neon-lit digital realm.`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-3-flash-preview',
        messages: [
          { role: 'system', content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: 'Rate limit exceeded. Please wait a moment.' }), {
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: 'Payment required. Please add credits to your workspace.' }), {
          status: 402,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      
      return new Response(JSON.stringify({ error: 'AI processing error' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('Streaming response from Lovable AI');

    // Transform the stream to extract and store memories
    const reader = response.body!.getReader();
    let fullContent = '';
    
    const stream = new ReadableStream({
      async start(controller) {
        const decoder = new TextDecoder();
        
        while (true) {
          const { done, value } = await reader.read();
          if (done) {
            // After streaming completes, extract and store memories
            if (user_id && fullContent) {
              const memoryMatches = fullContent.matchAll(/\[MEMORY:\s*(\w+)=([^\]]+)\]/gi);
              for (const match of memoryMatches) {
                const key = match[1].toLowerCase();
                const value = match[2].trim();
                
                console.log('Storing memory:', key, '=', value);
                
                // Upsert the memory
                await supabase
                  .from('user_memories')
                  .upsert({
                    user_id,
                    memory_key: key,
                    memory_value: value,
                    category: 'general',
                  }, {
                    onConflict: 'user_id,memory_key',
                  });
              }
            }
            controller.close();
            break;
          }
          
          // Accumulate content for memory extraction
          const chunk = decoder.decode(value, { stream: true });
          
          // Parse SSE to extract content
          const lines = chunk.split('\n');
          for (const line of lines) {
            if (line.startsWith('data: ') && line !== 'data: [DONE]') {
              try {
                const json = JSON.parse(line.slice(6));
                const content = json.choices?.[0]?.delta?.content;
                if (content) {
                  fullContent += content;
                }
              } catch { /* ignore parsing errors */ }
            }
          }
          
          controller.enqueue(value);
        }
      }
    });

    return new Response(stream, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  } catch (error) {
    console.error('Chat function error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
