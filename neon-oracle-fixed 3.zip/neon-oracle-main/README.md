# NEON-CORE — Neural Interface AI

A cyberpunk-themed AI chat interface with animated robot, holographic panels, and achievement system.

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Add your Anthropic API key to `.env`:
   ```
   VITE_ANTHROPIC_API_KEY=sk-ant-...
   ```

3. Run locally:
   ```bash
   npm run dev
   ```

4. Open `http://localhost:8080`

## What changed from the original

- **Removed Supabase auth** — no login required, works instantly
- **Removed Supabase backend** — calls Anthropic API directly  
- **Removed lovable-tagger** — was a Lovable.dev-only build dependency
- All UI components (robot, machine, particles, achievements) are unchanged

## Notes

- The Vite dev server proxies `/api/anthropic` → `https://api.anthropic.com` to avoid CORS issues in development
- For production deployment, set `VITE_ANTHROPIC_API_KEY` in your host's environment variables
- The `anthropic-dangerous-direct-browser-access: true` header is required for direct browser API calls
