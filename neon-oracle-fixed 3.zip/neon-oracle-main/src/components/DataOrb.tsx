import { motion } from 'framer-motion';

interface DataOrbProps {
  visible: boolean;
  position: 'input' | 'robot' | 'machine' | 'output';
  color?: string;
}

export const DataOrb = ({ visible, position, color = 'hsl(180, 100%, 50%)' }: DataOrbProps) => {
  const getPosition = () => {
    switch (position) {
      case 'input': return { x: 0, y: 0, scale: 0.8 };
      case 'robot': return { x: 100, y: -50, scale: 1 };
      case 'machine': return { x: 200, y: -20, scale: 1.2 };
      case 'output': return { x: 300, y: 50, scale: 0.9 };
    }
  };

  const pos = getPosition();

  if (!visible) return null;

  return (
    <motion.div
      className="absolute z-20 pointer-events-none"
      style={{ left: '10%', top: '50%' }}
      initial={{ x: 0, y: 0, scale: 0, opacity: 0 }}
      animate={{ 
        x: pos.x,
        y: pos.y,
        scale: pos.scale,
        opacity: 1,
      }}
      transition={{ 
        type: 'spring',
        stiffness: 100,
        damping: 15
      }}
    >
      <div className="relative w-12 h-12">
        {/* Outer glow */}
        <motion.div
          className="absolute inset-0 rounded-full blur-xl"
          style={{ background: color }}
          animate={{ 
            opacity: [0.4, 0.8, 0.4],
            scale: [1, 1.3, 1]
          }}
          transition={{ duration: 0.8, repeat: Infinity }}
        />
        
        {/* Main orb */}
        <motion.div
          className="absolute inset-2 rounded-full"
          style={{ 
            background: `radial-gradient(circle at 30% 30%, ${color}, transparent 70%)`,
            boxShadow: `0 0 20px ${color}, 0 0 40px ${color}`,
          }}
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
        />
        
        {/* Inner core */}
        <motion.div
          className="absolute inset-4 rounded-full"
          style={{ background: color }}
          animate={{ 
            opacity: [0.8, 1, 0.8],
            scale: [0.9, 1.1, 0.9]
          }}
          transition={{ duration: 0.5, repeat: Infinity }}
        />

        {/* Data streams */}
        {[0, 60, 120, 180, 240, 300].map(angle => (
          <motion.div
            key={angle}
            className="absolute left-1/2 top-1/2 w-0.5 h-4 origin-bottom"
            style={{ 
              background: `linear-gradient(to top, ${color}, transparent)`,
              transform: `rotate(${angle}deg) translateY(-100%)`,
            }}
            animate={{ 
              opacity: [0, 1, 0],
              scaleY: [0.5, 1, 0.5]
            }}
            transition={{ 
              duration: 0.6,
              repeat: Infinity,
              delay: angle / 360
            }}
          />
        ))}
      </div>
    </motion.div>
  );
};
