import { motion, AnimatePresence } from 'framer-motion';
import { useEffect } from 'react';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
}

interface AchievementPopupProps {
  achievement: Achievement | null;
  onDismiss: () => void;
}

export const AchievementPopup = ({ achievement, onDismiss }: AchievementPopupProps) => {
  useEffect(() => {
    if (achievement) {
      const timer = setTimeout(onDismiss, 4000);
      return () => clearTimeout(timer);
    }
  }, [achievement, onDismiss]);

  return (
    <AnimatePresence>
      {achievement && (
        <motion.div
          className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50"
          initial={{ opacity: 0, y: -50, scale: 0.8 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.9 }}
          transition={{ type: 'spring', stiffness: 200, damping: 20 }}
        >
          <div className="relative">
            {/* Glow effect */}
            <motion.div
              className="absolute inset-0 rounded-lg blur-xl"
              style={{ background: 'hsl(45, 100%, 50%)' }}
              animate={{ opacity: [0.3, 0.6, 0.3] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
            
            <div className="relative bg-black/95 rounded-lg border border-amber-500/50 px-6 py-4 min-w-[280px]">
              {/* Header */}
              <div className="flex items-center gap-3 mb-2">
                <motion.div
                  className="text-3xl"
                  animate={{ 
                    rotate: [0, -10, 10, 0],
                    scale: [1, 1.2, 1]
                  }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  {achievement.icon}
                </motion.div>
                <div>
                  <motion.div
                    className="text-xs font-mono text-amber-500/70 uppercase tracking-wider"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 }}
                  >
                    Achievement Unlocked
                  </motion.div>
                  <motion.div
                    className="text-lg font-orbitron font-bold text-amber-400"
                    style={{ textShadow: '0 0 10px hsl(45, 100%, 50%)' }}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 }}
                  >
                    {achievement.title}
                  </motion.div>
                </div>
              </div>
              
              <motion.p
                className="text-sm font-mono text-amber-300/70"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                {achievement.description}
              </motion.p>

              {/* Sparkles */}
              {[...Array(6)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-1 h-1 rounded-full bg-amber-400"
                  style={{
                    left: `${10 + Math.random() * 80}%`,
                    top: `${10 + Math.random() * 80}%`,
                  }}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ 
                    opacity: [0, 1, 0],
                    scale: [0, 1, 0],
                    y: [0, -20]
                  }}
                  transition={{ 
                    duration: 1,
                    delay: 0.2 + i * 0.1,
                    repeat: 2
                  }}
                />
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export const achievements = {
  firstQuery: {
    id: 'first-query',
    title: 'First Query Initiated',
    description: 'You have established connection with NEXUS-7',
    icon: '🚀',
  },
  deepThinker: {
    id: 'deep-thinker',
    title: 'Deep Thinker',
    description: 'Asked a question with more than 100 characters',
    icon: '🧠',
  },
  systemOverload: {
    id: 'system-overload',
    title: 'System Overload',
    description: 'Sent 10 queries in a single session',
    icon: '⚡',
  },
  easterEgg: {
    id: 'easter-egg',
    title: 'Secret Discovered',
    description: 'You found a hidden interaction',
    icon: '🔮',
  },
  conversationalist: {
    id: 'conversationalist',
    title: 'Conversationalist',
    description: 'Engaged in 5 back-and-forth exchanges',
    icon: '💬',
  },
};
