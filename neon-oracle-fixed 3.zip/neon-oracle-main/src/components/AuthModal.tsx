import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { User, Lock, Mail, LogIn, UserPlus, X, Loader2 } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSignIn: (email: string, password: string) => Promise<unknown>;
  onSignUp: (email: string, password: string) => Promise<unknown>;
}

export const AuthModal = ({ isOpen, onClose, onSignIn, onSignUp }: AuthModalProps) => {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === 'signin') {
        await onSignIn(email, password);
      } else {
        await onSignUp(email, password);
      }
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* Backdrop */}
          <motion.div
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            onClick={onClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />

          {/* Modal */}
          <motion.div
            className="relative z-10 w-full max-w-md mx-4 holographic-panel p-8"
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: 'spring', damping: 25 }}
          >
            {/* Close button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-muted-foreground hover:text-primary transition-colors"
            >
              <X size={20} />
            </button>

            {/* Header */}
            <div className="text-center mb-6">
              <motion.div
                className="w-16 h-16 mx-auto mb-4 rounded-full border-2 border-primary/50 flex items-center justify-center"
                animate={{ 
                  boxShadow: ['0 0 20px hsl(180, 100%, 50%, 0.3)', '0 0 40px hsl(180, 100%, 50%, 0.5)', '0 0 20px hsl(180, 100%, 50%, 0.3)']
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <User className="w-8 h-8 text-primary" />
              </motion.div>
              <h2 className="text-2xl font-orbitron font-bold text-neon-cyan">
                {mode === 'signin' ? 'NEURAL LINK' : 'CREATE IDENTITY'}
              </h2>
              <p className="text-xs font-mono text-muted-foreground mt-1">
                {mode === 'signin' ? 'Authenticate to access NEON-CORE' : 'Register new neural signature'}
              </p>
            </div>

            {/* Error display */}
            {error && (
              <motion.div
                className="mb-4 p-3 border border-destructive/50 bg-destructive/10 rounded text-sm text-destructive font-mono"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                {error}
              </motion.div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email address"
                  required
                  className="w-full pl-11 pr-4 py-3 bg-background/50 border border-primary/30 rounded-lg 
                    font-mono text-foreground placeholder:text-muted-foreground
                    focus:outline-none focus:border-primary focus:shadow-[0_0_10px_hsl(180,100%,50%,0.3)]
                    transition-all duration-300"
                />
              </div>

              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  required
                  minLength={6}
                  className="w-full pl-11 pr-4 py-3 bg-background/50 border border-primary/30 rounded-lg 
                    font-mono text-foreground placeholder:text-muted-foreground
                    focus:outline-none focus:border-primary focus:shadow-[0_0_10px_hsl(180,100%,50%,0.3)]
                    transition-all duration-300"
                />
              </div>

              <motion.button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-primary/20 border border-primary rounded-lg
                  font-orbitron font-bold text-primary tracking-wider
                  hover:bg-primary/30 hover:shadow-[0_0_20px_hsl(180,100%,50%,0.5)]
                  disabled:opacity-50 disabled:cursor-not-allowed
                  transition-all duration-300 flex items-center justify-center gap-2"
                whileHover={{ scale: loading ? 1 : 1.02 }}
                whileTap={{ scale: loading ? 1 : 0.98 }}
              >
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : mode === 'signin' ? (
                  <>
                    <LogIn className="w-5 h-5" />
                    AUTHENTICATE
                  </>
                ) : (
                  <>
                    <UserPlus className="w-5 h-5" />
                    REGISTER
                  </>
                )}
              </motion.button>
            </form>

            {/* Toggle mode */}
            <div className="mt-6 text-center">
              <button
                onClick={() => setMode(mode === 'signin' ? 'signup' : 'signin')}
                className="text-sm font-mono text-muted-foreground hover:text-primary transition-colors"
              >
                {mode === 'signin' 
                  ? 'No identity? Create one' 
                  : 'Already registered? Sign in'}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
