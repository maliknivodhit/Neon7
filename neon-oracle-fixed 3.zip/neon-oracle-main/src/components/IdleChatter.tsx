import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface IdleChatterProps {
  isIdle: boolean;
  onChatter?: (message: string) => void;
}

const idleMessages = [
  "Quantum coherence stable at 99.7%...",
  "Neural pathways optimizing...",
  "Awaiting organic input...",
  "Memory banks defragmenting...",
  "Consciousness subroutines active...",
  "Scanning for new data streams...",
  "Processing ambient signals...",
  "System diagnostics nominal...",
  "Ready for cognitive engagement...",
  "Monitoring quantum fluctuations...",
];

export const IdleChatter = ({ isIdle }: IdleChatterProps) => {
  const [message, setMessage] = useState<string | null>(null);
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    if (!isIdle) {
      setMessage(null);
      return;
    }

    const showMessage = () => {
      const randomMessage = idleMessages[Math.floor(Math.random() * idleMessages.length)];
      setMessage(randomMessage);
      setMessageIndex(prev => prev + 1);
      
      // Hide message after 3 seconds
      setTimeout(() => setMessage(null), 3000);
    };

    // Show first message after 8 seconds of idle
    const initialTimer = setTimeout(showMessage, 8000);
    
    // Then show messages periodically
    const interval = setInterval(showMessage, 12000);

    return () => {
      clearTimeout(initialTimer);
      clearInterval(interval);
    };
  }, [isIdle]);

  return (
    <AnimatePresence>
      {message && (
        <motion.div
          key={messageIndex}
          className="absolute -top-16 left-1/2 transform -translate-x-1/2 whitespace-nowrap"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3 }}
        >
          <div className="relative">
            {/* Speech bubble */}
            <div className="bg-black/90 border border-primary/30 rounded-lg px-4 py-2">
              <motion.span
                className="font-mono text-xs text-primary/70"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                {message}
              </motion.span>
            </div>
            {/* Bubble tail */}
            <div 
              className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-full"
              style={{
                width: 0,
                height: 0,
                borderLeft: '6px solid transparent',
                borderRight: '6px solid transparent',
                borderTop: '6px solid hsl(180, 100%, 25%)',
              }}
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
