import { motion } from 'framer-motion';
import type { RobotMood } from './Robot';

interface MoodIndicatorProps {
  mood: RobotMood;
  systemStatus: string;
}

export const MoodIndicator = ({ mood, systemStatus }: MoodIndicatorProps) => {
  const getMoodConfig = () => {
    switch (mood) {
      case 'calm':
        return {
          color: 'hsl(180, 100%, 50%)',
          label: 'CALM',
          icon: '◈',
          pulse: 3,
        };
      case 'focused':
        return {
          color: 'hsl(270, 100%, 60%)',
          label: 'FOCUSED',
          icon: '◉',
          pulse: 1.5,
        };
      case 'intense':
        return {
          color: 'hsl(320, 100%, 50%)',
          label: 'INTENSE',
          icon: '◆',
          pulse: 0.8,
        };
    }
  };

  const config = getMoodConfig();

  return (
    <motion.div
      className="fixed top-20 right-4 z-30"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.5 }}
    >
      <div className="relative">
        {/* Glow effect */}
        <motion.div
          className="absolute inset-0 rounded-lg blur-xl opacity-30"
          style={{ background: config.color }}
          animate={{ opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: config.pulse, repeat: Infinity }}
        />
        
        <div 
          className="relative bg-black/90 rounded-lg border px-4 py-3"
          style={{ borderColor: `${config.color}50` }}
        >
          <div className="flex items-center gap-3">
            {/* Mood icon */}
            <motion.div
              className="text-2xl"
              style={{ color: config.color, textShadow: `0 0 10px ${config.color}` }}
              animate={{ 
                scale: [1, 1.1, 1],
                opacity: [0.8, 1, 0.8]
              }}
              transition={{ duration: config.pulse, repeat: Infinity }}
            >
              {config.icon}
            </motion.div>
            
            <div>
              <div className="flex items-center gap-2">
                <span 
                  className="text-xs font-mono font-bold tracking-wider"
                  style={{ color: config.color }}
                >
                  {config.label}
                </span>
                <motion.div
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ background: config.color }}
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 0.5, repeat: Infinity }}
                />
              </div>
              <span className="text-xs font-mono text-muted-foreground">
                {systemStatus}
              </span>
            </div>
          </div>

          {/* Activity bar */}
          <div className="mt-2 flex gap-0.5">
            {Array.from({ length: 8 }).map((_, i) => (
              <motion.div
                key={i}
                className="w-2 h-1 rounded-sm"
                style={{ background: config.color }}
                animate={{ 
                  opacity: [0.2, 1, 0.2],
                  scaleY: [0.5, 1, 0.5]
                }}
                transition={{ 
                  duration: 0.5,
                  repeat: Infinity,
                  delay: i * 0.1
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
};
