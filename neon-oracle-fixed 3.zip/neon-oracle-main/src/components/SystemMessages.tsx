import { motion, AnimatePresence } from 'framer-motion';

interface SystemMessagesProps {
  messages: string[];
}

const systemPhrases = [
  "Analyzing input...",
  "Neural pathways engaged...",
  "Synthesizing intelligence...",
  "Processing quantum data...",
  "Accessing memory banks...",
  "Correlating patterns...",
  "Optimizing response matrix...",
  "Engaging cognitive cores...",
];

export const SystemMessages = ({ messages }: SystemMessagesProps) => {
  return (
    <div className="fixed bottom-24 left-1/2 transform -translate-x-1/2 z-30">
      <AnimatePresence mode="wait">
        {messages.map((message, index) => (
          <motion.div
            key={`${message}-${index}`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="text-center"
          >
            <motion.span
              className="inline-block px-4 py-2 rounded bg-black/80 border border-primary/30 font-mono text-sm text-primary"
              animate={{ opacity: [0.7, 1, 0.7] }}
              transition={{ duration: 0.8, repeat: Infinity }}
            >
              <motion.span
                className="inline-block mr-2"
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
              >
                ⟳
              </motion.span>
              {message}
            </motion.span>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};

export { systemPhrases };
