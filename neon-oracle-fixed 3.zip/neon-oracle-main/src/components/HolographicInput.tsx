import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';

interface HolographicInputProps {
  onSubmit: (message: string) => void;
  disabled?: boolean;
  maxLength?: number;
}

export const HolographicInput = ({ onSubmit, disabled, maxLength = 500 }: HolographicInputProps) => {
  const [input, setInput] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const energyLevel = Math.min((input.length / maxLength) * 100, 100);
  
  const handleSubmit = () => {
    if (input.trim() && !disabled) {
      onSubmit(input.trim());
      setInput('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.style.height = Math.min(inputRef.current.scrollHeight, 120) + 'px';
    }
  }, [input]);

  return (
    <motion.div
      className="relative w-full max-w-2xl mx-auto"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      {/* Holographic frame */}
      <motion.div
        className="absolute -inset-1 rounded-lg opacity-50"
        style={{
          background: `linear-gradient(135deg, hsl(180, 100%, 50%), hsl(270, 100%, 60%))`,
        }}
        animate={{
          opacity: isFocused ? 0.8 : 0.3,
        }}
        transition={{ duration: 0.3 }}
      />
      
      <motion.div
        className="absolute -inset-1 rounded-lg blur-md"
        style={{
          background: `linear-gradient(135deg, hsl(180, 100%, 50%), hsl(270, 100%, 60%))`,
        }}
        animate={{
          opacity: isFocused ? 0.4 : 0.1,
        }}
        transition={{ duration: 0.3 }}
      />

      <div className="relative bg-black/90 rounded-lg border border-primary/30 overflow-hidden">
        {/* Scanlines overlay */}
        <div className="absolute inset-0 pointer-events-none scanlines opacity-30" />
        
        {/* Header bar */}
        <div className="flex items-center justify-between px-4 py-2 border-b border-primary/20 bg-primary/5">
          <div className="flex items-center gap-2">
            <motion.div
              className="w-2 h-2 rounded-full bg-primary"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
            <span className="text-xs font-mono text-primary/70">NEURAL_INPUT_TERMINAL v2.7</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-muted-foreground">
              {input.length}/{maxLength}
            </span>
          </div>
        </div>

        {/* Input area */}
        <div className="relative p-4">
          <div className="flex items-start gap-2">
            <motion.span
              className="text-primary font-mono text-lg mt-1"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 0.8, repeat: Infinity }}
            >
              {'>>'}
            </motion.span>
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value.slice(0, maxLength))}
              onKeyDown={handleKeyDown}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              disabled={disabled}
              placeholder="Enter your query for NEXUS-7..."
              className="flex-1 bg-transparent text-primary font-mono text-base resize-none outline-none placeholder:text-primary/30 min-h-[24px] max-h-[120px]"
              rows={1}
            />
          </div>
        </div>

        {/* Energy meter */}
        <div className="px-4 pb-3">
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-muted-foreground">ENERGY</span>
            <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
              <motion.div
                className="h-full rounded-full"
                style={{
                  background: energyLevel > 80 
                    ? 'hsl(0, 100%, 50%)' 
                    : energyLevel > 50 
                      ? 'hsl(45, 100%, 50%)' 
                      : 'hsl(180, 100%, 50%)',
                  boxShadow: energyLevel > 80 
                    ? '0 0 10px hsl(0, 100%, 50%)' 
                    : '0 0 10px hsl(180, 100%, 50%)',
                }}
                animate={{ width: `${energyLevel}%` }}
                transition={{ duration: 0.2 }}
              />
            </div>
            <motion.button
              onClick={handleSubmit}
              disabled={disabled || !input.trim()}
              className="px-4 py-1.5 rounded cyber-button text-sm disabled:opacity-30 disabled:cursor-not-allowed"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              TRANSMIT
            </motion.button>
          </div>
        </div>

        {/* Animated corner accents */}
        <svg className="absolute top-0 left-0 w-6 h-6 text-primary" viewBox="0 0 24 24">
          <motion.path
            d="M 0 12 L 0 0 L 12 0"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            animate={{ opacity: [0.3, 1, 0.3] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </svg>
        <svg className="absolute top-0 right-0 w-6 h-6 text-primary rotate-90" viewBox="0 0 24 24">
          <motion.path
            d="M 0 12 L 0 0 L 12 0"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            animate={{ opacity: [0.3, 1, 0.3] }}
            transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
          />
        </svg>
        <svg className="absolute bottom-0 left-0 w-6 h-6 text-primary -rotate-90" viewBox="0 0 24 24">
          <motion.path
            d="M 0 12 L 0 0 L 12 0"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            animate={{ opacity: [0.3, 1, 0.3] }}
            transition={{ duration: 2, repeat: Infinity, delay: 1 }}
          />
        </svg>
        <svg className="absolute bottom-0 right-0 w-6 h-6 text-primary rotate-180" viewBox="0 0 24 24">
          <motion.path
            d="M 0 12 L 0 0 L 12 0"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            animate={{ opacity: [0.3, 1, 0.3] }}
            transition={{ duration: 2, repeat: Infinity, delay: 1.5 }}
          />
        </svg>
      </div>
    </motion.div>
  );
};
