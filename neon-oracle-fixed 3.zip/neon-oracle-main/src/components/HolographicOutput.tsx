import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

interface HolographicOutputProps {
  messages: Message[];
  isStreaming?: boolean;
}

export const HolographicOutput = ({ messages, isStreaming }: HolographicOutputProps) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [displayedChars, setDisplayedChars] = useState<Record<string, number>>({});

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  // Typewriter effect for new messages
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.role === 'assistant' && isStreaming) {
      setDisplayedChars(prev => ({
        ...prev,
        [lastMessage.id]: lastMessage.content.length
      }));
    }
  }, [messages, isStreaming]);

  const highlightKeywords = (text: string) => {
    // Highlight technical terms and keywords
    const keywords = ['NEXUS-7', 'neural', 'processing', 'quantum', 'analysis', 'data', 'system', 'core', 'matrix'];
    let result = text;
    
    keywords.forEach(keyword => {
      const regex = new RegExp(`(${keyword})`, 'gi');
      result = result.replace(regex, '<span class="text-neon-cyan">$1</span>');
    });
    
    return result;
  };

  return (
    <motion.div
      className="relative w-full max-w-2xl mx-auto h-full min-h-[260px]"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.2 }}
    >
      {/* Holographic frame effect */}
      <div className="absolute -inset-0.5 rounded-lg bg-gradient-to-b from-secondary/30 to-primary/30 opacity-50" />
      <div className="absolute -inset-0.5 rounded-lg bg-gradient-to-b from-secondary/20 to-primary/20 blur-lg" />
      
      <div className="relative h-full bg-black/95 rounded-lg border border-primary/20 overflow-hidden">
        {/* Scanlines */}
        <div className="absolute inset-0 pointer-events-none scanlines opacity-20" />
        
        {/* Ambient glow at top */}
        <div className="absolute top-0 left-0 right-0 h-20 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />
        
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-2 border-b border-primary/20 bg-black/90 backdrop-blur">
          <div className="flex items-center gap-2">
            <motion.div
              className="w-2 h-2 rounded-full"
              style={{ background: 'hsl(150, 100%, 50%)' }}
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
            <span className="text-xs font-mono text-primary/70">NEURAL_OUTPUT_DISPLAY</span>
          </div>
          <div className="flex items-center gap-3">
            {isStreaming && (
              <motion.span
                className="text-xs font-mono text-accent"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 0.5, repeat: Infinity }}
              >
                RECEIVING...
              </motion.span>
            )}
            <span className="text-xs font-mono text-muted-foreground">
              {messages.length} TRANSMISSIONS
            </span>
          </div>
        </div>

        {/* Messages container */}
        <div
          ref={scrollRef}
          className="h-[calc(100%-40px)] overflow-y-auto px-4 py-4 space-y-4 scroll-smooth no-scrollbar overscroll-contain"
        >
          <AnimatePresence mode="popLayout">
            {messages.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center h-full text-center"
              >
                <motion.div
                  className="text-6xl mb-4"
                  animate={{ 
                    opacity: [0.3, 0.6, 0.3],
                    scale: [0.98, 1.02, 0.98]
                  }}
                  transition={{ duration: 3, repeat: Infinity }}
                >
                  ⟁
                </motion.div>
                <p className="text-muted-foreground font-mono text-sm">
                  AWAITING NEURAL INPUT...
                </p>
                <p className="text-muted-foreground/50 font-mono text-xs mt-2">
                  Type a message to initiate communication with NEXUS-7
                </p>
              </motion.div>
            ) : (
              messages.map((message, index) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`relative max-w-[85%] px-4 py-3 rounded-lg ${
                      message.role === 'user'
                        ? 'bg-primary/10 border border-primary/30 ml-8'
                        : 'bg-secondary/10 border border-secondary/30 mr-8'
                    }`}
                  >
                    {/* Role indicator */}
                    <div className={`text-xs font-mono mb-1 ${
                      message.role === 'user' ? 'text-primary/60' : 'text-secondary/60'
                    }`}>
                      {message.role === 'user' ? 'USER_INPUT' : 'NEXUS-7'}
                    </div>
                    
                    {/* Message content */}
                    <div 
                      className={`font-mono text-sm leading-relaxed ${
                        message.role === 'user' ? 'text-primary/90' : 'text-secondary/90'
                      }`}
                      dangerouslySetInnerHTML={{ 
                        __html: message.role === 'assistant' 
                          ? highlightKeywords(message.content)
                          : message.content
                      }}
                    />

                    {/* Corner accents for assistant messages */}
                    {message.role === 'assistant' && (
                      <>
                        <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-secondary/50" />
                        <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-secondary/50" />
                      </>
                    )}
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>

          {/* Streaming indicator */}
          {isStreaming && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center gap-2 text-accent/70 font-mono text-xs"
            >
              <motion.span
                animate={{ opacity: [0.3, 1, 0.3] }}
                transition={{ duration: 0.6, repeat: Infinity }}
              >
                ▊
              </motion.span>
              Processing neural pathways...
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
};
