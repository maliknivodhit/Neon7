import { motion, AnimatePresence } from 'framer-motion';

export type MachineState = 'idle' | 'receiving' | 'scanning' | 'analyzing' | 'computing' | 'outputReady';

interface ProcessingMachineProps {
  state: MachineState;
  progress: number;
}

export const ProcessingMachine = ({ state, progress }: ProcessingMachineProps) => {
  const isActive = state !== 'idle';
  
  const getStateColor = () => {
    switch (state) {
      case 'idle': return 'hsl(180, 100%, 30%)';
      case 'receiving': return 'hsl(180, 100%, 50%)';
      case 'scanning': return 'hsl(270, 100%, 60%)';
      case 'analyzing': return 'hsl(320, 100%, 50%)';
      case 'computing': return 'hsl(210, 100%, 60%)';
      case 'outputReady': return 'hsl(150, 100%, 50%)';
    }
  };

  return (
    <div className="relative w-64 h-80 flex items-center justify-center">
      {/* Outer glow */}
      <motion.div
        className="absolute inset-0 rounded-lg blur-3xl"
        style={{ background: getStateColor() }}
        animate={{ 
          opacity: isActive ? [0.2, 0.4, 0.2] : 0.1,
          scale: isActive ? [1, 1.05, 1] : 1,
        }}
        transition={{ duration: 1.5, repeat: Infinity }}
      />

      <svg viewBox="0 0 200 250" className="w-full h-full relative z-10">
        <defs>
          <linearGradient id="machineGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="hsl(220, 30%, 12%)" />
            <stop offset="100%" stopColor="hsl(220, 30%, 5%)" />
          </linearGradient>
          <filter id="machineGlow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
          <clipPath id="coreClip">
            <circle cx="100" cy="125" r="35" />
          </clipPath>
        </defs>

        {/* Main body */}
        <rect x="30" y="30" width="140" height="190" rx="10" fill="url(#machineGradient)" stroke={getStateColor()} strokeWidth="2" filter="url(#machineGlow)" />

        {/* Top section - Input port */}
        <rect x="50" y="40" width="100" height="30" rx="5" fill="hsl(220, 30%, 5%)" stroke={getStateColor()} strokeWidth="1" />
        <motion.rect
          x="55"
          y="50"
          width="90"
          height="10"
          rx="2"
          fill={getStateColor()}
          animate={state === 'receiving' ? { opacity: [0.3, 1, 0.3] } : { opacity: 0.2 }}
          transition={{ duration: 0.5, repeat: state === 'receiving' ? Infinity : 0 }}
        />

        {/* Outer rotating rings */}
        <motion.g
          style={{ transformOrigin: '100px 125px' }}
          animate={{ rotate: isActive ? 360 : 0 }}
          transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
        >
          <circle cx="100" cy="125" r="55" fill="none" stroke={getStateColor()} strokeWidth="1" opacity="0.3" strokeDasharray="10 5" />
        </motion.g>
        
        <motion.g
          style={{ transformOrigin: '100px 125px' }}
          animate={{ rotate: isActive ? -360 : 0 }}
          transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
        >
          <circle cx="100" cy="125" r="48" fill="none" stroke={getStateColor()} strokeWidth="1.5" opacity="0.5" strokeDasharray="8 8" />
        </motion.g>

        <motion.g
          style={{ transformOrigin: '100px 125px' }}
          animate={{ rotate: isActive ? 360 : 0 }}
          transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
        >
          <circle cx="100" cy="125" r="42" fill="none" stroke={getStateColor()} strokeWidth="2" opacity="0.7" strokeDasharray="5 10" />
        </motion.g>

        {/* Central core */}
        <circle cx="100" cy="125" r="35" fill="hsl(220, 30%, 3%)" stroke={getStateColor()} strokeWidth="2" />
        
        {/* Core inner pattern */}
        <motion.circle
          cx="100"
          cy="125"
          r="25"
          fill="none"
          stroke={getStateColor()}
          strokeWidth="1"
          animate={isActive ? { 
            r: [25, 30, 25],
            opacity: [0.5, 1, 0.5]
          } : {}}
          transition={{ duration: 1, repeat: Infinity }}
        />

        {/* Core center orb */}
        <motion.circle
          cx="100"
          cy="125"
          r="15"
          fill={getStateColor()}
          filter="url(#machineGlow)"
          animate={isActive ? { 
            opacity: [0.6, 1, 0.6],
            r: [15, 18, 15]
          } : { opacity: 0.3 }}
          transition={{ duration: 0.8, repeat: Infinity }}
        />

        {/* Scanning beam */}
        <AnimatePresence>
          {state === 'scanning' && (
            <motion.line
              x1="65"
              y1="125"
              x2="135"
              y2="125"
              stroke={getStateColor()}
              strokeWidth="2"
              filter="url(#machineGlow)"
              initial={{ y1: 90, y2: 90, opacity: 0 }}
              animate={{ y1: [90, 160, 90], y2: [90, 160, 90], opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1, repeat: Infinity }}
            />
          )}
        </AnimatePresence>

        {/* Energy pulses during computing */}
        <AnimatePresence>
          {state === 'computing' && (
            <>
              {[0, 1, 2, 3].map(i => (
                <motion.circle
                  key={i}
                  cx="100"
                  cy="125"
                  r="15"
                  fill="none"
                  stroke={getStateColor()}
                  strokeWidth="2"
                  initial={{ r: 15, opacity: 1 }}
                  animate={{ r: 55, opacity: 0 }}
                  transition={{ 
                    duration: 1.5,
                    repeat: Infinity,
                    delay: i * 0.3,
                    ease: 'easeOut'
                  }}
                />
              ))}
            </>
          )}
        </AnimatePresence>

        {/* Side panels with indicators */}
        {[40, 55, 70, 85].map((y, i) => (
          <g key={y}>
            <rect x="35" y={y + 100} width="15" height="8" rx="1" fill="hsl(220, 30%, 5%)" stroke={getStateColor()} strokeWidth="0.5" />
            <motion.rect
              x="37"
              y={y + 102}
              width="11"
              height="4"
              rx="1"
              fill={getStateColor()}
              animate={{ opacity: isActive ? [0.2, 1, 0.2] : 0.1 }}
              transition={{ duration: 0.5 + i * 0.2, repeat: Infinity, delay: i * 0.1 }}
            />
          </g>
        ))}
        {[40, 55, 70, 85].map((y, i) => (
          <g key={`r-${y}`}>
            <rect x="150" y={y + 100} width="15" height="8" rx="1" fill="hsl(220, 30%, 5%)" stroke={getStateColor()} strokeWidth="0.5" />
            <motion.rect
              x="152"
              y={y + 102}
              width="11"
              height="4"
              rx="1"
              fill={getStateColor()}
              animate={{ opacity: isActive ? [0.2, 1, 0.2] : 0.1 }}
              transition={{ duration: 0.5 + i * 0.2, repeat: Infinity, delay: i * 0.1 + 0.05 }}
            />
          </g>
        ))}

        {/* Output port */}
        <rect x="50" y="185" width="100" height="25" rx="5" fill="hsl(220, 30%, 5%)" stroke={getStateColor()} strokeWidth="1" />
        <motion.rect
          x="55"
          y="192"
          width={90 * (progress / 100)}
          height="10"
          rx="2"
          fill={state === 'outputReady' ? 'hsl(150, 100%, 50%)' : getStateColor()}
          animate={state === 'outputReady' ? { opacity: [0.7, 1, 0.7] } : {}}
          transition={{ duration: 0.3, repeat: state === 'outputReady' ? Infinity : 0 }}
        />

        {/* Status text */}
        <text x="100" y="230" textAnchor="middle" fill={getStateColor()} fontSize="8" fontFamily="'Share Tech Mono', monospace">
          {state.toUpperCase().replace(/([A-Z])/g, ' $1').trim()}
        </text>
      </svg>

      {/* Floating data particles */}
      <AnimatePresence>
        {isActive && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {Array.from({ length: 8 }).map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 rounded-full"
                style={{ 
                  background: getStateColor(),
                  left: `${30 + Math.random() * 40}%`,
                  top: '80%',
                  boxShadow: `0 0 10px ${getStateColor()}`
                }}
                initial={{ y: 0, opacity: 0 }}
                animate={{ 
                  y: -150 - Math.random() * 50,
                  opacity: [0, 1, 0],
                  x: (Math.random() - 0.5) * 30
                }}
                transition={{ 
                  duration: 1.5 + Math.random(),
                  repeat: Infinity,
                  delay: i * 0.2
                }}
              />
            ))}
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
