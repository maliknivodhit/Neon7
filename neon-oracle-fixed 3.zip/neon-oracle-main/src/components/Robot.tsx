import { motion, AnimatePresence } from 'framer-motion';

export type RobotState = 'idle' | 'thinking' | 'grabbing' | 'inserting' | 'delivering' | 'excited' | 'curious' | 'confused';
export type RobotMood = 'calm' | 'focused' | 'intense';

interface RobotProps {
  state: RobotState;
  mood: RobotMood;
}

export const Robot = ({ state, mood }: RobotProps) => {
  const getMoodColor = () => {
    switch (mood) {
      case 'calm': return 'hsl(180, 100%, 50%)';
      case 'focused': return 'hsl(270, 100%, 60%)';
      case 'intense': return 'hsl(320, 100%, 50%)';
    }
  };

  const getEyeAnimation = () => {
    switch (state) {
      case 'thinking':
        return { scaleY: [1, 0.3, 1], transition: { duration: 0.5, repeat: Infinity, repeatDelay: 1 } };
      case 'curious':
        return { scaleY: 1.2, y: -2 };
      case 'confused':
        return { rotateZ: [-5, 5, -5], transition: { duration: 0.3, repeat: Infinity } };
      case 'excited':
        return { scale: [1, 1.3, 1], transition: { duration: 0.3, repeat: Infinity } };
      default:
        return { scaleY: [1, 0.1, 1], transition: { duration: 0.15, repeat: Infinity, repeatDelay: 3 } };
    }
  };

  const getBodyAnimation = () => {
    switch (state) {
      case 'thinking':
        return { rotateZ: [-3, 3, -3], transition: { duration: 2, repeat: Infinity, ease: 'easeInOut' } };
      case 'grabbing':
        return { x: 30, transition: { duration: 0.5 } };
      case 'inserting':
        return { x: -30, transition: { duration: 0.5 } };
      case 'delivering':
        return { x: [0, 20, 0], transition: { duration: 1 } };
      case 'excited':
        return { y: [-5, 5, -5], transition: { duration: 0.2, repeat: Infinity } };
      default:
        return { y: [0, -3, 0], transition: { duration: 3, repeat: Infinity, ease: 'easeInOut' } };
    }
  };

  return (
    <motion.div 
      className="relative w-32 h-40"
      animate={getBodyAnimation()}
    >
      {/* Glow effect behind robot */}
      <motion.div
        className="absolute inset-0 rounded-full blur-2xl opacity-30"
        style={{ background: getMoodColor() }}
        animate={{ 
          opacity: [0.2, 0.4, 0.2],
          scale: [1, 1.1, 1],
        }}
        transition={{ duration: 2, repeat: Infinity }}
      />
      
      {/* Robot body */}
      <svg viewBox="0 0 100 120" className="w-full h-full">
        {/* Body gradient */}
        <defs>
          <linearGradient id="bodyGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="hsl(220, 30%, 15%)" />
            <stop offset="100%" stopColor="hsl(220, 30%, 8%)" />
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>

        {/* Antenna */}
        <motion.g
          animate={{ rotateZ: state === 'thinking' ? [-10, 10, -10] : 0 }}
          transition={{ duration: 1, repeat: state === 'thinking' ? Infinity : 0 }}
          style={{ transformOrigin: '50px 20px' }}
        >
          <line x1="50" y1="20" x2="50" y2="5" stroke={getMoodColor()} strokeWidth="2" filter="url(#glow)" />
          <circle cx="50" cy="3" r="3" fill={getMoodColor()} filter="url(#glow)" />
        </motion.g>

        {/* Head */}
        <rect x="25" y="20" width="50" height="35" rx="8" fill="url(#bodyGradient)" stroke={getMoodColor()} strokeWidth="1" filter="url(#glow)" />
        
        {/* Eyes container */}
        <g>
          {/* Left eye */}
          <motion.ellipse
            cx="38"
            cy="37"
            rx="6"
            ry="8"
            fill={getMoodColor()}
            filter="url(#glow)"
            animate={getEyeAnimation()}
          />
          {/* Right eye */}
          <motion.ellipse
            cx="62"
            cy="37"
            rx="6"
            ry="8"
            fill={getMoodColor()}
            filter="url(#glow)"
            animate={getEyeAnimation()}
          />
          {/* Pupils */}
          <motion.circle
            cx="38"
            cy="37"
            r="2"
            fill="hsl(220, 30%, 8%)"
            animate={state === 'curious' ? { x: 2 } : {}}
          />
          <motion.circle
            cx="62"
            cy="37"
            r="2"
            fill="hsl(220, 30%, 8%)"
            animate={state === 'curious' ? { x: 2 } : {}}
          />
        </g>

        {/* Mouth/speaker grille */}
        <motion.g
          animate={state === 'excited' ? { scaleX: [1, 1.2, 1] } : {}}
          transition={{ duration: 0.3, repeat: state === 'excited' ? Infinity : 0 }}
          style={{ transformOrigin: '50px 50px' }}
        >
          <rect x="40" y="48" width="20" height="4" rx="2" fill={getMoodColor()} opacity="0.5" />
        </motion.g>

        {/* Neck */}
        <rect x="42" y="55" width="16" height="10" fill="url(#bodyGradient)" stroke={getMoodColor()} strokeWidth="0.5" />

        {/* Torso */}
        <path 
          d="M 25 65 L 75 65 L 80 100 L 20 100 Z" 
          fill="url(#bodyGradient)" 
          stroke={getMoodColor()} 
          strokeWidth="1"
          filter="url(#glow)"
        />

        {/* Chest panel with energy indicator */}
        <rect x="35" y="72" width="30" height="20" rx="3" fill="hsl(220, 30%, 5%)" stroke={getMoodColor()} strokeWidth="0.5" />
        <motion.rect
          x="38"
          y="75"
          width="24"
          height="4"
          rx="1"
          fill={getMoodColor()}
          animate={{ opacity: [0.3, 1, 0.3] }}
          transition={{ duration: 1, repeat: Infinity }}
        />
        <motion.rect
          x="38"
          y="81"
          width="24"
          height="4"
          rx="1"
          fill={getMoodColor()}
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.2, repeat: Infinity, delay: 0.2 }}
        />
        <motion.rect
          x="38"
          y="87"
          width="24"
          height="4"
          rx="1"
          fill={getMoodColor()}
          animate={{ opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 1.4, repeat: Infinity, delay: 0.4 }}
        />

        {/* Arms */}
        <AnimatePresence>
          {/* Left arm */}
          <motion.path
            d={state === 'grabbing' || state === 'inserting' 
              ? "M 20 70 Q 5 80 15 95" 
              : "M 20 70 Q 10 85 15 100"}
            fill="none"
            stroke={getMoodColor()}
            strokeWidth="4"
            strokeLinecap="round"
            filter="url(#glow)"
            animate={state === 'grabbing' ? { d: "M 20 70 Q 5 75 25 85" } : 
                     state === 'inserting' ? { d: "M 20 70 Q -10 80 0 95" } : {}}
            transition={{ duration: 0.3 }}
          />
          {/* Right arm */}
          <motion.path
            d={state === 'grabbing' || state === 'inserting'
              ? "M 80 70 Q 95 80 85 95"
              : "M 80 70 Q 90 85 85 100"}
            fill="none"
            stroke={getMoodColor()}
            strokeWidth="4"
            strokeLinecap="round"
            filter="url(#glow)"
            animate={state === 'delivering' ? { d: "M 80 70 Q 95 75 75 85" } : {}}
            transition={{ duration: 0.3 }}
          />
        </AnimatePresence>

        {/* Data streams when thinking */}
        {state === 'thinking' && (
          <g>
            {[0, 1, 2].map(i => (
              <motion.line
                key={i}
                x1={35 + i * 15}
                y1="100"
                x2={35 + i * 15}
                y2="110"
                stroke={getMoodColor()}
                strokeWidth="1"
                initial={{ y2: 100, opacity: 0 }}
                animate={{ 
                  y2: [100, 115, 100],
                  opacity: [0, 1, 0]
                }}
                transition={{ 
                  duration: 0.8,
                  repeat: Infinity,
                  delay: i * 0.2
                }}
              />
            ))}
          </g>
        )}
      </svg>

      {/* State indicator text */}
      <motion.div
        className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 text-xs font-mono whitespace-nowrap"
        style={{ color: getMoodColor() }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.7 }}
      >
        {state.toUpperCase()}
      </motion.div>
    </motion.div>
  );
};
