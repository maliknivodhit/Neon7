import { motion } from 'framer-motion';
import { User, LogOut, Brain } from 'lucide-react';

interface UserBadgeProps {
  email?: string;
  memoryCount: number;
  onSignOut: () => void;
}

export const UserBadge = ({ email, memoryCount, onSignOut }: UserBadgeProps) => {
  return (
    <motion.div
      className="fixed top-4 right-4 z-40 flex items-center gap-3"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.3 }}
    >
      {/* Memory indicator */}
      <div className="flex items-center gap-2 px-3 py-1.5 bg-neon-purple/10 border border-neon-purple/30 rounded-full">
        <Brain className="w-4 h-4 text-neon-purple" />
        <span className="text-xs font-mono text-neon-purple">{memoryCount} memories</span>
      </div>

      {/* User info */}
      <div className="flex items-center gap-2 px-3 py-1.5 bg-primary/10 border border-primary/30 rounded-full">
        <User className="w-4 h-4 text-primary" />
        <span className="text-xs font-mono text-primary truncate max-w-[120px]">
          {email}
        </span>
      </div>

      {/* Sign out button */}
      <motion.button
        onClick={onSignOut}
        className="p-2 bg-destructive/10 border border-destructive/30 rounded-full
          hover:bg-destructive/20 transition-colors"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        title="Sign out"
      >
        <LogOut className="w-4 h-4 text-destructive" />
      </motion.button>
    </motion.div>
  );
};
