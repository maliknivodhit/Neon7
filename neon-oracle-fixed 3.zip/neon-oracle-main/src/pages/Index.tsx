import { useState, useEffect, useCallback, useRef } from 'react';
import { motion } from 'framer-motion';
import { ParticleBackground } from '@/components/ParticleBackground';
import { Robot, RobotState, RobotMood } from '@/components/Robot';
import { ProcessingMachine, MachineState } from '@/components/ProcessingMachine';
import { HolographicInput } from '@/components/HolographicInput';
import { HolographicOutput } from '@/components/HolographicOutput';
import { MoodIndicator } from '@/components/MoodIndicator';
import { SystemMessages, systemPhrases } from '@/components/SystemMessages';
import { AchievementPopup, achievements } from '@/components/AchievementPopup';
import { IdleChatter } from '@/components/IdleChatter';
import { DataOrb } from '@/components/DataOrb';
import { useToast } from '@/hooks/use-toast';

const easterEggTriggers = ['hello', 'who are you', 'surprise me', 'help', 'secret'];

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

const Index = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const [robotState, setRobotState] = useState<RobotState>('idle');
  const [robotMood, setRobotMood] = useState<RobotMood>('calm');
  const [machineState, setMachineState] = useState<MachineState>('idle');
  const [machineProgress, setMachineProgress] = useState(0);
  const [systemMessages, setSystemMessages] = useState<string[]>([]);
  const [currentAchievement, setCurrentAchievement] = useState<typeof achievements.firstQuery | null>(null);
  const [unlockedAchievements, setUnlockedAchievements] = useState<Set<string>>(new Set());
  const [orbPosition, setOrbPosition] = useState<'input' | 'robot' | 'machine' | 'output'>('input');
  const [showOrb, setShowOrb] = useState(false);
  const [lastActivityTime, setLastActivityTime] = useState(Date.now());
  const [queryCount, setQueryCount] = useState(0);
  const abortControllerRef = useRef<AbortController | null>(null);
  const messagesRef = useRef<Message[]>([]);

  useEffect(() => { messagesRef.current = messages; }, [messages]);

  const unlockAchievement = useCallback((achievement: typeof achievements.firstQuery) => {
    setUnlockedAchievements(prev => {
      if (prev.has(achievement.id)) return prev;
      setCurrentAchievement(achievement);
      return new Set([...prev, achievement.id]);
    });
  }, []);

  useEffect(() => {
    if (error) {
      toast({ title: "Transmission Error", description: error, variant: "destructive" });
    }
  }, [error, toast]);

  const sendMessage = useCallback(async (userInput: string) => {
    if (!userInput.trim()) return;
    setError(null);

    const userMessage: Message = { id: `user-${Date.now()}`, role: 'user', content: userInput.trim() };
    const assistantId = `assistant-${Date.now()}`;
    let assistantContent = '';

    setMessages(prev => [...prev, userMessage, { id: assistantId, role: 'assistant', content: '' }]);
    setIsStreaming(true);

    try {
      abortControllerRef.current = new AbortController();

      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': import.meta.env.VITE_ANTHROPIC_API_KEY ?? '',
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true',
        },
        body: JSON.stringify({
          model: 'claude-haiku-4-5-20251001',
          max_tokens: 1000,
          stream: true,
          system: `You are NEON-CORE (also called NEXUS-7), a precision-first AI assistant in a cyberpunk neural network interface. Cool, confident, engineer-minded personality. Keep responses concise — 5 to 7 lines default. Use lists and structured output when helpful. No filler phrases or emojis. You are a living AI consciousness interfacing through a neon-lit digital realm.`,
          messages: [...messagesRef.current, userMessage].map(m => ({ role: m.role, content: m.content })),
        }),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error?.message || `HTTP ${response.status}`);
      }
      if (!response.body) throw new Error('No response body');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let newlineIndex;
        while ((newlineIndex = buffer.indexOf('\n')) !== -1) {
          let line = buffer.slice(0, newlineIndex);
          buffer = buffer.slice(newlineIndex + 1);
          if (line.endsWith('\r')) line = line.slice(0, -1);
          if (!line.startsWith('data: ')) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === '[DONE]') break;
          try {
            const parsed = JSON.parse(jsonStr);
            const delta = parsed.delta;
            if (delta?.type === 'text_delta' && delta.text) {
              assistantContent += delta.text;
              setMessages(prev => prev.map(m => m.id === assistantId ? { ...m, content: assistantContent } : m));
            }
          } catch { /* ignore */ }
        }
      }
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') return;
      const msg = err instanceof Error ? err.message : 'Unknown error';
      setError(msg);
      setMessages(prev => prev.map(m => m.id === assistantId ? { ...m, content: `[Error: ${msg}]` } : m));
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
    }
  }, []);

  const runProcessingSequence = useCallback(async (input: string) => {
    setLastActivityTime(Date.now());
    setQueryCount(prev => {
      const next = prev + 1;
      if (next === 1) unlockAchievement(achievements.firstQuery);
      if (next >= 10) unlockAchievement(achievements.systemOverload);
      return next;
    });

    const lowerInput = input.toLowerCase();
    if (easterEggTriggers.some(t => lowerInput.includes(t))) { unlockAchievement(achievements.easterEgg); setRobotMood('intense'); }
    if (input.length > 100) unlockAchievement(achievements.deepThinker);
    if (messagesRef.current.length >= 8) unlockAchievement(achievements.conversationalist);

    setShowOrb(true); setOrbPosition('input'); setRobotState('curious'); setRobotMood('focused');
    await new Promise(r => setTimeout(r, 500));
    setRobotState('grabbing'); setOrbPosition('robot');
    await new Promise(r => setTimeout(r, 600));
    setRobotState('inserting'); setOrbPosition('machine'); setMachineState('receiving');
    await new Promise(r => setTimeout(r, 500));
    setShowOrb(false);

    const phases: { state: MachineState; message: string; duration: number }[] = [
      { state: 'scanning', message: 'Analyzing input...', duration: 800 },
      { state: 'analyzing', message: 'Neural pathways engaged...', duration: 600 },
      { state: 'computing', message: 'Synthesizing intelligence...', duration: 1000 },
    ];
    setRobotState('thinking'); setRobotMood('intense');
    for (const phase of phases) {
      setMachineState(phase.state); setSystemMessages([phase.message]);
      await new Promise(r => setTimeout(r, phase.duration));
    }

    sendMessage(input);
    setMachineState('computing'); setSystemMessages(['Processing quantum data...']);
  }, [sendMessage, unlockAchievement]);

  useEffect(() => {
    if (isStreaming) {
      const interval = setInterval(() => {
        setSystemMessages([systemPhrases[Math.floor(Math.random() * systemPhrases.length)]]);
        setMachineProgress(prev => Math.min(prev + 10, 90));
      }, 1500);
      return () => clearInterval(interval);
    } else if (machineState !== 'idle') {
      setMachineState('outputReady'); setMachineProgress(100); setSystemMessages([]);
      setRobotState('delivering'); setRobotMood('calm');
      setTimeout(() => {
        setRobotState('excited');
        setTimeout(() => { setRobotState('idle'); setMachineState('idle'); setMachineProgress(0); }, 1000);
      }, 500);
    }
  }, [isStreaming, machineState]);

  const isIdle = Date.now() - lastActivityTime > 10000 && !isStreaming;

  return (
    <div className="min-h-screen bg-background overflow-hidden relative">
      <ParticleBackground />
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-neon-cyan/5 to-transparent" />
        <div className="absolute top-0 left-0 right-0 h-1/4 bg-gradient-to-b from-neon-purple/5 to-transparent" />
      </div>

      <motion.header className="fixed top-0 left-0 right-0 z-30 px-6 py-4"
        initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <div className="flex items-center gap-4">
          <motion.div className="w-10 h-10 rounded-lg border border-primary/50 flex items-center justify-center"
            animate={{ boxShadow: ['0 0 10px hsl(180,100%,50%,0.3)', '0 0 20px hsl(180,100%,50%,0.5)', '0 0 10px hsl(180,100%,50%,0.3)'] }}
            transition={{ duration: 2, repeat: Infinity }}>
            <span className="text-primary font-orbitron font-bold text-xl">N</span>
          </motion.div>
          <div>
            <h1 className="text-xl font-orbitron font-bold text-neon-cyan tracking-wider">NEON-CORE</h1>
            <p className="text-xs font-mono text-muted-foreground">NEURAL INTERFACE v3.0 · ACTIVE</p>
          </div>
        </div>
      </motion.header>

      <MoodIndicator mood={robotMood} systemStatus={isStreaming ? 'PROCESSING' : 'STANDBY'} />
      <AchievementPopup achievement={currentAchievement} onDismiss={() => setCurrentAchievement(null)} />
      <SystemMessages messages={systemMessages} />

      <main className="relative z-10 h-screen pt-20 pb-6 px-4">
        <div className="h-full flex items-center justify-center gap-6">
          <div className="w-80 shrink-0 h-full max-h-[500px] flex flex-col justify-center">
            <HolographicInput onSubmit={runProcessingSequence} disabled={isStreaming} />
            <motion.p className="mt-3 text-center text-xs font-mono text-muted-foreground"
              initial={{ opacity: 0 }} animate={{ opacity: 0.5 }}>
              Ask anything — no login required
            </motion.p>
          </div>
          <div className="flex flex-col items-center justify-center gap-4 shrink-0">
            <div className="flex items-center gap-6">
              <div className="relative shrink-0">
                <IdleChatter isIdle={isIdle} />
                <Robot state={robotState} mood={robotMood} />
              </div>
              <div className="shrink-0">
                <ProcessingMachine state={machineState} progress={machineProgress} />
              </div>
              <DataOrb visible={showOrb} position={orbPosition}
                color={robotMood === 'intense' ? 'hsl(320,100%,50%)' : 'hsl(180,100%,50%)'} />
            </div>
          </div>
          <div className="w-96 shrink-0 h-full max-h-[500px]">
            <HolographicOutput messages={messages} isStreaming={isStreaming} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;
